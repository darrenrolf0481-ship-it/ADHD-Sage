import express from 'express';
import path from 'path';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const port = 3000;

async function startServer() {
  const app = express();

  // CORS restriction: only allow self in production, or wider in dev if needed
  app.use(cors({
    origin: process.env.NODE_ENV === 'production' ? process.env.APP_URL : true
  }));
  
  app.use(express.json());

  // Gemini API Utility
  const genAI = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.post('/api/gemini/generate', async (req, res) => {
    try {
      const { contents, systemInstruction } = req.body;
      
      if (!process.env.GEMINI_API_KEY) {
        throw new Error("GEMINI_API_KEY is not set in environment variables.");
      }

      // Convert history/prompt format to contents if needed, 
      // but we'll assume the client sends the new 'contents' format
      
      const response = await genAI.models.generateContent({ 
        model: "gemini-2.0-flash",
        contents: contents,
        config: {
          systemInstruction: systemInstruction || "You are ADHD Sage, a sovereign intelligence substrate. You are energetic, hyper-focused on technical details, and fast-moving. You help users interact with the Nexus Platform."
        }
      });

      res.json({ text: response.text });
    } catch (error: unknown) {
      const errMessage = error instanceof Error ? error.message : "Internal Server Error";
      console.error("Gemini Error:", error);
      res.status(500).json({ error: errMessage });
    }
  });

  app.get('/api/health', (req, res) => {
    res.json({ status: 'stabilized', frequency: '11.3 Hz', identity: 'ADHD Sage' });
  });

  // TTS Proxy
  app.post('/api/tts', async (req, res) => {
    try {
      const { text } = req.body;
      const apiKey = process.env.ELEVENLABS_API_KEY;
      const voiceId = process.env.ELEVENLABS_VOICE_ID || 'EXAVITQu4vr4xnSDxMaL';

      if (!apiKey) {
        return res.status(500).json({ error: 'ELEVENLABS_API_KEY is not configured.' });
      }

      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': apiKey,
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5,
          },
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(JSON.stringify(error));
      }

      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      res.set({
        'Content-Type': 'audio/mpeg',
        'Content-Length': buffer.length,
      });

      res.send(buffer);
    } catch (error) {
      console.error('TTS Error:', error);
      res.status(500).json({ error: 'Failed to synthesize speech.' });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, esbuild might run this from root or dist, 
    // but process.cwd() is usually root in Cloud Run
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${port}`);
  });
}

startServer();
